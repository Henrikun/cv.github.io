/** *************Angular app JS*********************/
"use strict"; 
var app = angular.module('contactApp', []);